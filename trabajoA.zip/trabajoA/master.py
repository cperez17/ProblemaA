from http.server import BaseHTTPRequestHandler, HTTPServer
import requests
from urllib.parse import urlparse, parse_qs
import json


SLAVES = {
    "libros": "http://localhost:8001",
    "articulos": "http://localhost:8002",
    "tesis": "http://localhost:8003",
    "videos": "http://localhost:8004"
}

class MasterHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        path = parsed.path

        if path == "/query":
            titulo = query.get("titulo", [""])[0]
            tipo_docs = query.get("tipo_doc", [])
            edad = query.get("edad", [""])[0]

            results = []

            if titulo:
                for url in SLAVES.values():
                    r = requests.get(f"{url}/query?titulo={titulo}&edad={edad}")
                    if r.status_code == 200:
                        results.extend(r.json())
            elif tipo_docs:
                for tipo in tipo_docs[0].split("+"):
                    url = SLAVES.get(tipo)
                    if url:
                        r = requests.get(f"{url}/query?titulo=&edad={edad}")
                        if r.status_code == 200:
                            results.extend(r.json())

            results.sort(key=lambda x: x["ranking"], reverse=True)
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(results, ensure_ascii=False).encode("utf-8"))

if __name__ == "__main__":
    server = HTTPServer(("localhost", 8000), MasterHandler)
    print("Servidor maestro corriendo en puerto 8000")
    server.serve_forever()
