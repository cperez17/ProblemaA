from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from urllib.parse import urlparse, parse_qs

PORT = 8002  # único por esclavo

class SlaveHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        if parsed.path == "/query":
            with open("Articulos.json", encoding="utf-8") as f:
                data = json.load(f)["articulos"]
            results = []

            titulo_terms = query.get("titulo", [""])[0].lower().split()
            edad = int(query.get("edad", [0])[0]) if "edad" in query else None

            for doc in data:
                score = sum(1 for term in titulo_terms if term in doc["titulo"].lower())
                score += genero_bonus(doc["genero"], edad)
                if score > 0:
                    doc["ranking"] = score
                    results.append(doc)

            results.sort(key=lambda x: x["ranking"], reverse=True)
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(results, ensure_ascii=False).encode("utf-8"))

def genero_bonus(genero, edad):
    genero = genero.lower()
    if edad is None:
        return 0
    if 10 <= edad <= 15 and "ciencia ficción" in genero:
        return 2
    elif 16 <= edad <= 25 and "educativo" in genero:
        return 2
    elif edad > 25 and ("historia" in genero or "técnica" in genero):
        return 2
    return 0

if __name__ == "__main__":
    server = HTTPServer(('localhost', PORT), SlaveHandler)
    print(f"Servidor esclavo (Libros) corriendo en puerto {PORT}")
    server.serve_forever()
