import http.server
import json
import urllib.parse

class SlaveHandler(http.server.BaseHTTPRequestHandler):
    def load_data(self):
        """Carga los datos desde el archivo JSON y accede a la clave raíz apropiada"""
        with open(self.server.data_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            key = self.get_data_key()
            return data.get(key, [])

    def get_data_key(self):
        """Método que deben implementar las subclases para especificar la clave raíz del JSON"""
        raise NotImplementedError("Subclases deben implementar get_data_key()")

    def do_GET(self):
        if self.path.startswith("/search"):
            query = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(query)
            search_terms = params.get("titulo", [""])[0].lower().split()
            age = int(params.get("age", ["0"])[0])

            data = self.load_data()
            results = []

            for item in data:
                titulo = item.get("titulo", "").lower()
                genero = item.get("genero", "").lower()

                # Ranking por coincidencia de palabras en el título
                rank = sum(1 for term in search_terms if term in titulo)

                # Ajuste por edad y género
                if 10 <= age <= 15 and "ciencia ficción" in genero:
                    rank += 2  # bonus por edad y género

                if rank > 0:
                    item_with_rank = item.copy()
                    item_with_rank["rank"] = rank
                    results.append(item_with_rank)

            results.sort(key=lambda x: x["rank"], reverse=True)

            self.send_response(200)
            self.send_header("Content-type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps(results, ensure_ascii=False, indent=2).encode("utf-8"))

def run_slave(handler_class, port, data_file):
    server = http.server.HTTPServer(('localhost', port), handler_class)
    server.data_file = data_file
    print(f"Esclavo corriendo en http://localhost:{port}/search")
    server.serve_forever()
